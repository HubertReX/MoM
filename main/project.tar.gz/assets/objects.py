from dataclasses import dataclass
import random
from typing import Callable
import pygame

from settings import (
    BLACK_COLOR,
    CHAR_NAME_COLOR,
    FONT_SIZE_EXTRA_TINY,
    HUD_DIR,
    IS_WEB,
    MAIN_FONT,
    PANEL_BG_COLOR,
    TILE_SIZE,
    TRANSPARENT_COLOR,
    entity_name,
    load_image,
)
from enums import AttitudeEnum, ItemTypeEnum, NotificationTypeEnum
if IS_WEB:
    from config_model.config import Character, Item, Chest
else:
    from config_model.config_pydantic import Character, Item, Chest  # type: ignore[assignment]

#################################################################################################################


class Collider(pygame.sprite.Sprite):
    def __init__(
        self,
        groups: pygame.sprite.Group,
        pos: tuple[int, int],
        size: tuple[int, int],
        name: str,
        to_map: str,
        entry_point: str,
        is_maze: bool,
        maze_cols: int,
        maze_rows: int,
        return_entry_point: str = ""
    ) -> None:

        super().__init__(groups)
        self.image: pygame.Surface = pygame.Surface((size))
        self.rect: pygame.FRect = self.image.get_frect(topleft = pos)
        self.name = name
        self.to_map = to_map
        self.entry_point = entry_point
        self.is_maze = is_maze
        self.maze_cols = maze_cols
        self.maze_rows = maze_rows
        self.return_entry_point = return_entry_point

#################################################################################################################


class Shadow(pygame.sprite.Sprite):
    def __init__(self,
                 groups: pygame.sprite.Group,
                 pos: tuple[int, int],
                 size: tuple[int, int],
                 empty: bool = False
                 ) -> None:
        super().__init__(groups)
        self.image: pygame.Surface = pygame.Surface((size)).convert_alpha()
        self.rect: pygame.FRect = self.image.get_frect(topleft = pos)
        self.image.fill(TRANSPARENT_COLOR)
        # self.image.set_colorkey("black")
        if not empty:
            pygame.draw.ellipse(self.image, BLACK_COLOR, self.rect)


#################################################################################################################
class InventorySlot(pygame.sprite.Sprite):
    def __init__(self, item_model: Item | None, pos: tuple[int, int], scale: int) -> None:
        super().__init__()
        # self.image: pygame.Surface = pygame.Surface((70 * scale * TILE_SIZE, 16 * scale * TILE_SIZE)).convert_alpha()
        self.item_model = item_model

        self.image_full: pygame.Surface = load_image(HUD_DIR / "inventorySlot.png").convert_alpha()
        self.image_selector: pygame.Surface = load_image(HUD_DIR / "hotbar_selector.png").convert_alpha()

        if scale != 1:
            self.image_full = pygame.transform.scale(
                self.image_full, (scale * self.image_full.get_width(),
                                  scale * self.image_full.get_height()))

            self.image_selector = pygame.transform.scale(
                self.image_selector, (scale * self.image_selector.get_width(),
                                      scale * self.image_selector.get_height()))

        self.rect_full: pygame.Rect = self.image_full.get_rect(topleft = pos)

        self.image: pygame.Surface = self.image_full.subsurface(0, 0, self.rect_full.width, self.rect_full.width)
        self.image_selected: pygame.Surface = self.image_full.subsurface(
            0, self.rect_full.width, self.rect_full.width, self.rect_full.width)
        # self.image: pygame.Surface = pygame.Surface(self.image.get_size()).convert_alpha()
        # self.image.fill(TRANSPARENT_COLOR)

        self.rect: pygame.Rect = self.image.get_rect(topleft = pos)
        self.rect_selected: pygame.Rect = self.image_selected.get_rect(topleft = pos)
        self.rect_selector: pygame.Rect = self.image_selector.get_rect(topleft = pos)
        # self.rect_full: pygame.FRect = self.image.get_frect(topleft = pos)

#################################################################################################################


class HealthBarUI(pygame.sprite.Sprite):
    def __init__(self, model: Character, groups: pygame.sprite.Group, pos: tuple[int, int], scale: int) -> None:
        super().__init__()
        # self.image: pygame.Surface = pygame.Surface((70 * scale * TILE_SIZE, 16 * scale * TILE_SIZE)).convert_alpha()
        self.model = model

        self.image_full: pygame.Surface = load_image(HUD_DIR / "LifeBarMiniProgress.png").convert_alpha()
        self.image_empty: pygame.Surface = load_image(HUD_DIR / "LifeBarMiniUnder.png").convert_alpha()
        # self.image = pygame.transform.scale(self.image, (scale * TILE_SIZE, scale * TILE_SIZE))
        self.image_full = pygame.transform.scale(
            self.image_full, (scale * self.image_full.get_width(), scale * self.image_full.get_height()))
        self.image_empty = pygame.transform.scale(
            self.image_empty, (scale * self.image_empty.get_width(), scale * self.image_empty.get_height()))
        self.image: pygame.Surface = pygame.Surface(self.image_full.get_size()).convert_alpha()
        # self.image: pygame.Surface = pygame.Surface((700, 200)).convert_alpha()
        self.image.fill(TRANSPARENT_COLOR)

        self.rect: pygame.FRect = self.image.get_frect(topleft = pos)
        self.rect_full: pygame.FRect = self.image_full.get_frect(topleft = pos)
        # self.rect_full.x = self.rect.left
        # self.rect_full.y += 1
        self.color: pygame._common.ColorValue = "white"
        if self.model.attitude == AttitudeEnum.enemy.value:
            self.color = "red"
        elif self.model.attitude == AttitudeEnum.friendly.value:
            self.color = CHAR_NAME_COLOR
        elif self.model.attitude == AttitudeEnum.afraid.value:
            self.color = "green"
        else:
            self.color = "pink"

    #############################################################################################################
    def set_bar(self, percentage: float, pos: tuple[int, int]) -> None:
        self.rect.topleft = pos
        self.rect_full.topleft = pos
        # self.rect_full.left += 50
        # draw empty bar
        self.image.fill(TRANSPARENT_COLOR)  # TRANSPARENT_COLOR) PANEL_BG_COLOR

        # # leave image fully transparent (hide labels)
        # if percentage < 0.0:
        #     return

        # self.image.blit(self.image_full, self.rect_full.topleft)
        self.image.blit(self.image_full, (0, 0))

        percentage = min(1.0, percentage)
        percentage = max(0.0, percentage)
        width = int(self.rect_full.width * percentage)
        rect = pygame.Rect(width, 0, self.rect_full.width - width, self.image_full.get_height())
        tmp_img = self.image_empty.subsurface(rect)

        self.image.blit(tmp_img, (width, 0))

#################################################################################################################


class HealthBar(pygame.sprite.Sprite):
    def __init__(self,
                 name: str,
                 model: Character,
                 render_text: Callable,
                 groups: pygame.sprite.Group,
                 pos: tuple[int, int],
                 #  translate_pos: Callable
                 ) -> None:
        super().__init__(groups)
        self.image: pygame.Surface = pygame.Surface((125, 43)).convert_alpha()
        self.image.fill(TRANSPARENT_COLOR)
        self.visible: bool = True
        self.name = name
        self.model = model
        self.render_text = render_text
        self.translate_pos: Callable = lambda pos:  pos
        self.image_full: pygame.Surface = load_image(HUD_DIR / "LifeBarMiniProgress.png").convert_alpha()
        self.image_empty: pygame.Surface = load_image(HUD_DIR / "LifeBarMiniUnder.png").convert_alpha()
        self.rect: pygame.FRect = self.image.get_frect(midtop = pos)
        self.rect_full: pygame.FRect = self.image_full.get_frect()
        self.rect_full.x = self.rect.width // 2 - self.rect_full.width // 2
        self.rect_full.y += 1
        self.color: pygame._common.ColorValue = "white"
        if self.model.attitude == AttitudeEnum.enemy.value:
            self.color = "red"
        elif self.model.attitude == AttitudeEnum.friendly.value:
            self.color = CHAR_NAME_COLOR
        elif self.model.attitude == AttitudeEnum.afraid.value:
            self.color = "green"
        else:
            self.color = "pink"

    #############################################################################################################
    def set_bar(self, percentage: float) -> None:
        self.image.fill(TRANSPARENT_COLOR)

        # leave image fully transparent (hide labels)
        if percentage < 0.0:
            return
        y: int = 8
        # show health bar only for enemies
        if self.model.attitude == AttitudeEnum.enemy.value or self.model.name_EN == "Player":
            self.image.blit(self.image_full, self.rect_full.topleft)

            percentage = min(1.0, percentage)
            percentage = max(0.0, percentage)
            width = int(self.rect_full.width * percentage)
            rect = pygame.Rect(width, 0, self.rect_full.width - width, self.image_full.get_height())
            tmp_img = self.image_empty.subsurface(rect)

            self.image.blit(tmp_img, (self.rect_full.left + width, 1))

            y += 5

        # render name of the character (wrap at space if too wide)
        name = entity_name(self.model)
        fs = FONT_SIZE_EXTRA_TINY
        max_w = self.image.get_width() - 4
        _font = pygame.font.Font(MAIN_FONT, fs)
        line_h = fs + 4

        if _font.size(name)[0] <= max_w:
            self.render_text(
                name,
                (int(self.rect.width // 2), y),
                self.color,
                font_size=fs,
                shadow=(84, 135, 137),
                centred=True,
                surface=self.image
            )
        else:
            words = name.split()
            line1: list[str] = []
            for w in words:
                if _font.size(" ".join(line1 + [w]))[0] > max_w:
                    break
                line1.append(w)
            line2 = " ".join(words[len(line1):])
            s1 = " ".join(line1)
            cy = y if not line2 else y + line_h // 2
            self.render_text(
                s1,
                (int(self.rect.width // 2), cy - line_h // 2),
                self.color,
                font_size=fs,
                shadow=(84, 135, 137),
                centred=True,
                surface=self.image
            )
            if line2:
                self.render_text(
                    line2,
                    (int(self.rect.width // 2), cy + line_h // 2),
                    self.color,
                    font_size=fs,
                    shadow=(84, 135, 137),
                    centred=True,
                    surface=self.image
                )

#################################################################################################################
    def show(self) -> None:
        self.visible = True
        self.set_bar(self.model.health / self.model.max_health)

#################################################################################################################
    def hide(self) -> None:
        if not self.visible:
            return
        self.visible = False
        self.set_bar(-1)

#################################################################################################################


class Object(pygame.sprite.Sprite):
    def __init__(
        self,
        group: pygame.sprite.Group | None,
        pos: tuple[int, int],
        image: pygame.Surface  = pygame.Surface((TILE_SIZE, TILE_SIZE)),
        # z: str = "blocks",
    ) -> None:
        if group is not None:
            super().__init__(group)
        else:
            super().__init__()

        self.image = image
        self.rect: pygame.FRect = image.get_frect(topleft = pos)
        # self.hitbox: pygame.FRect = self.rect.copy().inflate(0, 0)
        # self.z = z
#################################################################################################################


class EmoteSprite(Object):
    def __init__(
        self,
        group: pygame.sprite.Group,
        pos: tuple[int, int],
        emotes: dict[str, list[pygame.Surface]],
        # emote: pygame.Surface  = pygame.Surface((TILE_SIZE, TILE_SIZE)),
        # z: str = "blocks",
    ) -> None:

        self.emotes = emotes
        self.emote: str = ""
        self.temporary_emote: str = ""
        self.temporary_emote_counter: float = 0.0
        self.frame_index: float = 0.0
        self.image: pygame.Surface = self.emotes["clear"][0]
        self.set_emote("clear")
        super().__init__(group, pos, self.image)

        self.rect: pygame.FRect = self.image.get_frect(midbottom = pos)

    def set_emote(self, emote: str) -> None:
        # if self.temporary_emote_counter > 0.0:
        #     print("set_emote", emote)

        if self.emote != emote:
            # if emote == "clear" and self.emote == "red_exclamation_anim":
            #     return

            self.emote = emote
            if not self.temporary_emote:
                self.frame_index = 0.0
                # self.image = self.emotes[self.emote][int(self.frame_index)]
                # self.image = self.emotes[self.emote][0]
                self.animate(0.0, forced=True)

    def clear_temporary_emote(self) -> None:
        self.temporary_emote = ""
        self.temporary_emote_counter = 0.0
        self.frame_index = 0.0
        self.animate(0.0, forced=True)

    def set_temporary_emote(self, emote: str, duration: float) -> None:
        # print("set_temporary_emote", emote)

        # if not self.temporary_emote:
        self.temporary_emote = emote
        self.temporary_emote_counter = duration
        self.frame_index = 0.0
        self.animate(0.0, forced=True)

    def animate(self, dt: float, forced: bool = False) -> None:
        # if self.temporary_emote_counter > 0.0:
        #             print(f"""before e={self.emote}
        # te={self.temporary_emote}
        # tec={self.temporary_emote_counter}
        # dt={dt:5.2f}
        # delta={(self.temporary_emote_counter - dt):5.2f}
        # fi={self.frame_index}""".replace("\n", " "))
        # skip if not animated and not forced
        # if "_anim" not in self.emote and forced == False:
        #     return

        self.frame_index += dt

        #         if self.temporary_emote_counter > 0.0:
        #             print(f"""after  e={self.emote}
        # te={self.temporary_emote}
        # tec={self.temporary_emote_counter}
        # dt={dt:5.2f}
        # delta={(self.temporary_emote_counter - dt):5.2f}
        # fi={self.frame_index}""".replace("\n", " "))

        if self.temporary_emote:
            self.temporary_emote_counter -= dt
            if self.temporary_emote_counter < 0.0:
                self.temporary_emote = ""

        active_emote = self.emote if not self.temporary_emote else self.temporary_emote

        if self.frame_index >= len(self.emotes[active_emote]):
            self.frame_index = 0.0  # if loop else len(self.emotes[self.emote]) - 1.0

        self.image = self.emotes[active_emote][int(self.frame_index)]  # .copy()

#################################################################################################################


class ItemSprite(Object):
    def __init__(
        self,
        group: pygame.sprite.Group | None,
        # gid: int,
        pos: tuple[int, int],
        # z: str = "blocks",
        name: str,
        model: Item,
        image: list[pygame.Surface] = [pygame.Surface((TILE_SIZE, TILE_SIZE))],
    ) -> None:

        super().__init__(group, pos, image[0])
        # decrease the size of rectangle for collisions aka. hitbox
        # self.hitbox: pygame.FRect = self.rect.copy().inflate(0, -self.rect.height / 2)
        # self.gid = gid
        self.name = name
        self.model = model
        if model.type == ItemTypeEnum.weapon:
            self.image_directions: dict[str, pygame.Surface] = {
                "down": image[0],
                "up": pygame.transform.flip(image[0], False, True),
            }
            self.image_directions["left"] = pygame.transform.rotate(image[0], -90)
            self.image_directions["right"] = pygame.transform.rotate(image[0], 90)

            # self.weapon_mask = pygame.mask.from_surface(self.image)
            self.masks: dict[str, pygame.mask.Mask] = {}
            for direction in self.image_directions:
                self.masks[direction] = pygame.mask.from_surface(self.image_directions[direction])

            self.mask: pygame.mask.Mask = self.masks["up"]

#################################################################################################################


class ChestSprite(Object):
    def __init__(
        self,
        group: pygame.sprite.Group | None,
        pos: tuple[int, int],
        # name: str,
        model: Chest,
        chests_sprites: dict[str, list[pygame.Surface]]
        # image_open: pygame.Surface = pygame.Surface((TILE_SIZE, TILE_SIZE)),
        # image_closed: pygame.Surface = pygame.Surface((TILE_SIZE, TILE_SIZE)),
    ) -> None:

        self.image_closed = chests_sprites["small_chest"][0] if model.is_small else chests_sprites["big_chest"][0]
        self.image_open = chests_sprites["small_chest"][1] if model.is_small else chests_sprites["big_chest"][1]
        image = self.image_closed if model.is_closed else self.image_open
        super().__init__(group, pos, image)
        # self.rect.center = pos
        self.model = model
        self.name = model.name

        self.generate_random_items()
        # self.is_closed = True
        # self.items: list[Item] = []

#################################################################################################################
    def generate_random_items(self) -> None:
        if len(self.model.random_items) == 0:
            return

        # self.model.items = []
        curr_count = len(self.model.items)

        if self.model.total_items_count - curr_count < 0:
            return

        # random.shuffle(self.model.random_items)
        # random.seed()
        for _ in range(self.model.total_items_count - curr_count):
            self.model.items.append(random.choice(self.model.random_items))

#################################################################################################################
    def open(self) -> None:
        self.image = self.image_open
        self.model.is_closed = False

#################################################################################################################
    def close(self) -> None:
        self.image = self.image_closed
        self.model.is_closed = True

#################################################################################################################


class DestructibleSprite(Object):
    def __init__(
        self,
        group: pygame.sprite.Group | None,
        pos: tuple[int, int],
        # name: str,
        # model: Chest,
        sprite: pygame.Surface,
        wall: pygame.Rect,
        prev_step_cost: int,
        type: str,
        # image_open: pygame.Surface = pygame.Surface((TILE_SIZE, TILE_SIZE)),
        # image_closed: pygame.Surface = pygame.Surface((TILE_SIZE, TILE_SIZE)),
    ) -> None:

        # self.image = sprite
        super().__init__(group, pos, sprite)
        self.mask = pygame.mask.from_surface(sprite)
        self.wall = wall
        self.step_cost = prev_step_cost
        self.type = type
        # self.rect.center = pos
        # self.model = model
        # self.name = model.name
        # self.is_closed = True


################################################################################################################


@dataclass(slots=True)
class Notification():
    type: NotificationTypeEnum
    message: str
    message_text: str
    width: int
    height: int
    create_time: float
    emote_key: str = ""
